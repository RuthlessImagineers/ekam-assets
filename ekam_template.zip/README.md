Ekam Template
