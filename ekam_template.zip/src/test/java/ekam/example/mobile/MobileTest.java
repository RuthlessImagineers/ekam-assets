package ekam.example.mobile;

import ekam.example.EkamTest;
import org.testng.annotations.Test;

public class MobileTest extends EkamTest {
    @Test
    public void exampleMobileTest() {

    }
}
