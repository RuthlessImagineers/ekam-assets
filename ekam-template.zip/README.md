### Ekam Template
--------------
Ekam, a rapid test automation platform, helps you to get started with WEB | MOBILE | API Test Automation. 

Follow below quick start guides.

## Quick Start Guides

* [Web Quick Start Guide](https://ekam.testvagrant.ai/docs/quick_start_guides/web_automation_guide/)
* Mobile Quick Start Guide 
* Api Quick Start Guide


