package ekam.example.api;

import ekam.example.EkamTest;
import org.testng.annotations.Test;

public class ApiTest extends EkamTest {
    @Test
    public void exampleApiTest() {

    }
}
