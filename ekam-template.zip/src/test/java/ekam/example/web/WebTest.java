package ekam.example.web;

import ekam.example.EkamTest;
import org.testng.annotations.Test;

public class WebTest extends EkamTest {

    @Test
    public void exampleWebTest() {
        
    }
}
